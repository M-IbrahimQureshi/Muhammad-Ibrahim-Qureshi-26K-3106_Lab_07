# include <stdio.h>
int main(){
	int i, j,Result;
	for(i=1; i<=5; i++){
		for(j=1; j<=i; j++){
			if(j%2 == 0)
				Result = j*j;
			else
				Result = j*j*j;
			printf("%d ", Result);
		}
		printf("\n");
	}
	
}
