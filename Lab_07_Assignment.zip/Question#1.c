// ShopKeeper Billing System
# include <stdio.h>
int main (){
	int Products[5][2];
	int i,x, Total, GrandTotal;
	Total = 0; GrandTotal = 0;
	
	for(i=0; i<5; i++){
		for(x=0; x<2; x++){
			if(x==0){
				printf("Enter Quantity of Product %d:\n ", i+1);
			}
			else
				printf("Enter Prize of Product %d:\n ", i+1);
			scanf("%d", &Products[i][x]);
			
		}
	}
	for(i=0; i<5; i++){
		for(x=0; x<2; x++){
				
		}
		Total = Products[i][0] * Products[i][1];
		GrandTotal = GrandTotal + Total;
		printf("%d\n", Total);
	}
	printf("%d\n", GrandTotal);	
}
